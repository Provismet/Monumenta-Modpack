In order to use your own custom music, replace the placeholder .ogg files in assets\epic\sounds\music with your own .ogg files you would like to loop during those locations in Monumenta.
You MUST keep the file names identical to the placeholder ones.

Be sure to toggle the features on in your PEB settings
.ogg files can be created using online converters or audio editing software like Audacity.